# TripoSR Mobile

Android starter project for a local image-to-3D app.

## Important
The official TripoSR implementation is Python/PyTorch and its documented local inference uses CUDA when available; the official README says a single image takes about 6GB VRAM. This project intentionally does NOT pretend that a WebView can run the original PyTorch model locally.

To make true on-device inference, the model must be converted/adapted to an Android-compatible runtime (for example ONNX Runtime / ExecuTorch) and the TripoSR custom operations must be supported or replaced. The UI and Android shell are ready for that integration.

## Build
Open in Android Studio and build the APK, or use the included GitHub Actions workflow.
