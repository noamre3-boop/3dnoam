package com.noam.triposr

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

class MainActivity : AppCompatActivity() {
    private val pick = 42
    private lateinit var status: TextView
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); buildUi() }
    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(28,32,28,24); setBackgroundColor(0xFF0B0D12.toInt()) }
        val title=TextView(this).apply { text="TripoSR Mobile"; textSize=30f; setTextColor(0xFFFFFFFF.toInt()) }
        val sub=TextView(this).apply { text="Image → 3D • Local Android app"; textSize=15f; setTextColor(0xFF9CA3AF.toInt()); setPadding(0,8,0,28) }
        val button=MaterialButton(this).apply { text="בחר תמונה"; setOnClickListener{startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="image/*";addCategory(Intent.CATEGORY_OPENABLE)},pick)} }
        status=TextView(this).apply { text="בחר תמונה כדי להתחיל"; textSize=16f; setTextColor(0xFFE5E7EB.toInt()); setPadding(0,28,0,0) }
        val note=TextView(this).apply { text="הערה: האפליקציה מוכנה לחיבור למנוע TripoSR. מודל PyTorch המקורי אינו ניתן להרצה ישירות בתוך WebView; כדי לבצע inference מקומי אמיתי צריך runtime/המרה ל-Android."; textSize=13f; setTextColor(0xFF9CA3AF.toInt()); setPadding(0,22,0,0) }
        root.addView(title);root.addView(sub);root.addView(button);root.addView(status);root.addView(note);setContentView(root)
    }
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){super.onActivityResult(requestCode,resultCode,data);if(requestCode==pick&&resultCode==Activity.RESULT_OK){status.text="נבחרה תמונה: ${data?.data?.lastPathSegment ?: "image"}\n\nשלב הבא: להריץ TripoSR מקומית על Android."}}
}
